# simple-wifi-controlled-rc-car
A really simple project using a NodeMCU motor shield to convert a RC car to have WiFi controls

[Check out instructables for more details on the project](https://www.instructables.com/id/Simple-WiFi-Controlled-RC-Car/)
